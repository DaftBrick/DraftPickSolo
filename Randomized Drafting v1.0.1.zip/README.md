# DraftPickSolo
Solo drafting tool for mainline FE

Instructions: (Macro-enabled sheet)

Pick sheet for wanted game.

Hit manual calc button

Place or remove (y for include) next to characters who you want to automatically be added to the auto-pick list (usually for lords / avatars / characters you just want to be included no matter what) or (n for exclude) to be removed from the drafting pool entirely.

MAKE SURE TO type in a number of draft picks wanted from 1-10 units in specified box at top. (Will be empty yellow box at start)

Hit the Auto calc button as many times as you feel like on this particular day, before MAKING SURE TO hit the manual calc button once again after shuffling
failure to do so will cause the sheet to keep shuffling even when you don't wawnt it.
(If for some reason the macro buttons are not working for you, go to Formulas>Calucale>Change Calculations to Manual, and then hit F9 as many times as you want to shuffle the pool)

A number of groups will have formed on the left side, pick one character from each to make your draft list. Space has been provided next to the groups to mark picked characters, as well as a small section next to the Includes/Excludes you can use as notes to manually write down your newly formed team.

NOTE: This workbook includes more than a few sheets in it and just as many hidden sheets that do the calculations and formatting for each front-side sheet.
It may run slow because of this on certain devices, but if it becomes an issue for multiple people, I will break it down into sheets based series / console the games were on (i.e. Tellius games or GBA games, etc.)

NOTE 2: Feedback is perfectly fine, send it to me through PM @daft on FEU (or the main thread itself) and daft1245 on discord also works. Any and all issues are fine to bring up, and any additions / edits are fine, but make sure to run it past me, and I will decide wether to add it (I will credit these on main thread as well for any specific help / additions I recieve from you).
